# AI Website Copy Generator for Local Businesses

This repository contains prompts and generated website copy for a sample local bakery.
