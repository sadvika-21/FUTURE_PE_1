# Services Prompt
Generate service descriptions for cakes, bread, cookies and pastries.