# Homepage Prompt
Create homepage copy for a local bakery with hero, about, benefits and CTA.